package br.com.fiap.beans;

public class Trem {
    private String codigo;
    private int numeroSerie;
    private String fabricante;
    private StatusTrem statusTrem;

    public Trem() {
        super();
    }

    public Trem(String codTrem, int numeroSerie, String fabricante) {
        super();
        this.codigo = codTrem;
        this.numeroSerie = numeroSerie;
        this.fabricante = fabricante;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(int numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public StatusTrem getStatusTrem() {
        return statusTrem;
    }

    public void setStatusTrem(StatusTrem statusTrem) {
        this.statusTrem = statusTrem;
    }

    @Override
    public String toString() {
        return "Trem{" +
                "\ncodTrem=" + codigo +
                "\numeroSerie=" + numeroSerie +
                "\nfabricante='" + fabricante + '\'' +
                "\nstatusTrem=" + statusTrem +
                '}';
    }
}
