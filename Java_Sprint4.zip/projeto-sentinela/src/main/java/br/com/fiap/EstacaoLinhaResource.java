package br.com.fiap;

import br.com.fiap.beans.EstacaoLinha;
import br.com.fiap.bo.EstacaoLinhaBO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/estacaolinha")
public class EstacaoLinhaResource {
    private EstacaoLinhaBO estacaoLinhaBO = new EstacaoLinhaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<EstacaoLinha> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<EstacaoLinha>) estacaoLinhaBO.selecionarBO();
    }

}
