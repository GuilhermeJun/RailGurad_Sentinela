package br.com.fiap.dao;

import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StatusTremDAO {

    public Connection minhaConexao;

    public StatusTremDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(StatusTrem statusTrem) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO STATUS_TREM VALUES (?, ?, ?)");

        stmt.setString(1, statusTrem.getCodigo());
        stmt.setString(2, statusTrem.getTipoStatus());
        stmt.setString(3, statusTrem.getDescricao());

        stmt.execute();
        stmt.close();

        return "Status do trem adicionado com sucesso!";
    }

    public List<StatusTrem> selecionar() throws SQLException {
        List<StatusTrem> listaStatusTrem = new ArrayList<StatusTrem>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select * from status_trem");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            StatusTrem statusTrem = new StatusTrem();
            statusTrem.setCodigo(rs.getString(1));
            statusTrem.setTipoStatus(rs.getString(2));
            statusTrem.setDescricao(rs.getString(3));
            listaStatusTrem.add(statusTrem);
        }
        stmt.close();
        return listaStatusTrem;
    }

    public StatusTrem buscarStatusTremPorCodigo(String codigo) throws SQLException {
        StatusTrem statusTrem = new StatusTrem();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from status_trem where cod_status = ?");
        stmt.setString(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            statusTrem.setCodigo(rs.getString(1));
            statusTrem.setTipoStatus(rs.getString(2));
            statusTrem.setDescricao(rs.getString(3));
        }
        stmt.close();
        return statusTrem;
    }
}
