package br.com.fiap.bo;

import br.com.fiap.beans.StatusTrem;
import br.com.fiap.dao.StatusTremDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class StatusTremBO {
    StatusTremDAO statusTremDAO;

    public ArrayList<StatusTrem> selecionarBO() throws SQLException, ClassNotFoundException {
        statusTremDAO = new StatusTremDAO();

        return (ArrayList<StatusTrem>) statusTremDAO.selecionar();
    }
}
