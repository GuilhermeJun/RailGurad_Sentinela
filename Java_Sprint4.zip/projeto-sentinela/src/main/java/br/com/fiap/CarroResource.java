package br.com.fiap;

import br.com.fiap.beans.Carro;
import br.com.fiap.bo.CarroBO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/carro")
public class CarroResource {
    private CarroBO carroBO = new CarroBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Carro> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<Carro>) carroBO.selecionarBO();
    }
}
