package br.com.fiap.dao;

import br.com.fiap.beans.Cargo;
import br.com.fiap.beans.Estacao;
import br.com.fiap.beans.Funcionario;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {

    public Connection minhaConexao;

    public FuncionarioDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Funcionario funcionario) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO FUNCIONARIO VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        stmt.setInt(1, funcionario.getCodigo());
        stmt.setString(2, funcionario.getCpf());
        stmt.setString(3, funcionario.getNome());
        stmt.setDate(4, funcionario.getDataNasc());
        stmt.setString(5, funcionario.getTelefone());
        stmt.setString(6, funcionario.getEmail());
        stmt.setString(7, funcionario.getSenha());
        stmt.setInt(8, funcionario.getCargo().getCodigo());
        stmt.setString(9, funcionario.getEstacao().getCodigo());

        stmt.execute();
        stmt.close();

        return "Novo funcionário cadastrado com sucesso!";
    }

    public List<Funcionario> selecionar() throws SQLException {
        List<Funcionario> listaFuncionario = new ArrayList<Funcionario>();

        PreparedStatement stmt = minhaConexao.prepareStatement("SELECT f.cod_func, f.cpf, f.nome_func, f.data_nasc, f.salario, f.num_telefone, f.email, c.cod_cargo, c.nome_cargo, c.descricao_cargo, e.cod_estacao, e.nome_estacao, e.localizacao FROM funcionario f JOIN cargo c ON f.fk_cargo = c.cod_cargo join estacao e ON f.fk_estacao = e.cod_estacao");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Funcionario funcionario = new Funcionario();
            funcionario.setCodigo(rs.getInt(1));
            funcionario.setCpf(rs.getString(2));
            funcionario.setNome(rs.getString(3));
            funcionario.setDataNasc(rs.getDate(4));
            funcionario.setSalario(rs.getDouble(5));
            funcionario.setTelefone(rs.getString(6));
            funcionario.setEmail(rs.getString(7));

            Cargo cargo = new Cargo();
            cargo.setCodigo(rs.getInt(8));
            cargo.setNome(rs.getString(9));
            cargo.setDescricao(rs.getString(10));
            funcionario.setCargo(cargo);

            Estacao estacao = new Estacao();
            estacao.setCodigo(rs.getString(11));
            estacao.setNome(rs.getString(12));
            estacao.setLocalizacao(rs.getString(13));
            funcionario.setEstacao(estacao);

            listaFuncionario.add(funcionario);
        }
        stmt.close();
        return listaFuncionario;
    }
}
