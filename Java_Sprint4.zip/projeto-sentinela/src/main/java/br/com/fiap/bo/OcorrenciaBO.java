package br.com.fiap.bo;

import br.com.fiap.beans.Ocorrencia;
import br.com.fiap.dao.OcorrenciaDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class OcorrenciaBO {
    OcorrenciaDAO ocorrenciaDAO;

    public ArrayList<Ocorrencia> selecionarBO() throws SQLException, ClassNotFoundException {
        ocorrenciaDAO = new OcorrenciaDAO();

        return (ArrayList<Ocorrencia>) ocorrenciaDAO.selecionar();
    }

    public void inserirBO(Ocorrencia ocorrencia) throws SQLException, ClassNotFoundException {
        OcorrenciaDAO ocorrenciaDAO = new OcorrenciaDAO();

        ocorrenciaDAO.inserir(ocorrencia);
    }

    public void atualizarBO(Ocorrencia ocorrencia) throws SQLException, ClassNotFoundException {
        OcorrenciaDAO ocorrenciaDAO = new OcorrenciaDAO();

        ocorrenciaDAO.atualizar(ocorrencia);
    }

    public void excluirBO(int codigo) throws SQLException, ClassNotFoundException {
        OcorrenciaDAO ocorrenciaDAO = new OcorrenciaDAO();

        ocorrenciaDAO.excluir(codigo);
    }
}
