package br.com.fiap.bo;

import br.com.fiap.beans.EstacaoLinha;
import br.com.fiap.dao.EstacaoLinhaDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class EstacaoLinhaBO {
    EstacaoLinhaDAO estacaoLinhaDAO;

    public ArrayList<EstacaoLinha> selecionarBO() throws SQLException, ClassNotFoundException {
        estacaoLinhaDAO = new EstacaoLinhaDAO();

        return (ArrayList<EstacaoLinha>) estacaoLinhaDAO.selecionar();
    }


}
