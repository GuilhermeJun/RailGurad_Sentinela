package br.com.fiap;

import br.com.fiap.beans.Estacao;
import br.com.fiap.bo.EstacaoBO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/estacao")
public class EstacaoResource {
    private EstacaoBO estacaoBO = new EstacaoBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Estacao> selecionarRs() throws SQLException, ClassNotFoundException {
        return (ArrayList<Estacao>) estacaoBO.selecionarBO();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response inserirRs(Estacao estacao, @Context UriInfo uriInfo) throws SQLException, ClassNotFoundException {
        estacaoBO.inserirBO(estacao);

        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(estacao.getCodigo());
        return Response.created(builder.build()).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizarRs(Estacao estacao, @PathParam("codigo") String codigo) throws SQLException, ClassNotFoundException {
        estacaoBO.atualizarBO(estacao);

        return Response.ok().build();
    }

    @DELETE
    @Path("/{codigo}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response excluirRs(@PathParam("codigo") String codigo) throws SQLException, ClassNotFoundException {
        estacaoBO.excluirBO(codigo);
        return Response.ok().build();
    }
}
