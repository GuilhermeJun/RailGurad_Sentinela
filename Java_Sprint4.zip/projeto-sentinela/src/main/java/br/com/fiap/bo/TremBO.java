package br.com.fiap.bo;

import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.dao.StatusTremDAO;
import br.com.fiap.dao.TremDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TremBO {
    TremDAO tremDAO;
    StatusTremDAO statusTremDAO;

    public ArrayList<Trem> selecionarBO() throws SQLException, ClassNotFoundException {
        tremDAO = new TremDAO();
        statusTremDAO = new StatusTremDAO();

        List<Trem> listaTrem = tremDAO.selecionar();

        for (Trem trem : listaTrem) {
            if (trem.getStatusTrem() != null && trem.getStatusTrem().getCodigo() != null) {
                StatusTrem statusTrem = statusTremDAO.buscarStatusTremPorCodigo(trem.getStatusTrem().getCodigo());
                trem.setStatusTrem(statusTrem);
            }
        }

        return (ArrayList<Trem>) tremDAO.selecionar();
    }
}
