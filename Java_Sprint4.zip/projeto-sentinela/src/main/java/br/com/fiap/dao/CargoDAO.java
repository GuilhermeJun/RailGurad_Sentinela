package br.com.fiap.dao;

import br.com.fiap.beans.Cargo;
import br.com.fiap.beans.Carro;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CargoDAO {

    public Connection minhaConexao;

    public CargoDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Cargo cargo) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO CARGO VALUES (?, ?, ?)");

        stmt.setInt(1, cargo.getCodigo());
        stmt.setString(2, cargo.getNome());
        stmt.setString(3, cargo.getDescricao());

        stmt.execute();
        stmt.close();

        return "Cargo cadastrado com sucesso!";
    }

    public List<Cargo> selecionar() throws SQLException {
        List<Cargo> listaCargo = new ArrayList<Cargo>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select * from cargo");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Cargo cargo = new Cargo();
            cargo.setCodigo(rs.getInt(1));
            cargo.setNome(rs.getString(2));
            cargo.setDescricao(rs.getString(3));

            listaCargo.add(cargo);
        }
        stmt.close();
        return listaCargo;
    }

    public Cargo buscarPorCodigo(int codigo) throws SQLException {
        Cargo cargo = new Cargo();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from cargo where cod_cargo = ?");
        stmt.setInt(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            cargo.setCodigo(rs.getInt(1));
            cargo.setNome(rs.getString(2));
        }
        stmt.close();
        return cargo;
    }
}
