package br.com.fiap.dao;

import br.com.fiap.beans.Linha;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LinhaDAO {

    public Connection minhaConexao;

    public LinhaDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Linha linha) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO LINHA VALUES (?, ?, ?)");

        stmt.setInt(1, linha.getNumero());
        stmt.setString(2, linha.getNome());
        stmt.setString(3, linha.getDescricao());

        stmt.execute();
        stmt.close();

        return "Linha de trem cadastrado com sucesso!";
    }

    public String atualizar(Linha linha) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE LINHA SET nome_linha = ?, descr_linha = ? WHERE numero = ?");

        stmt.setString(1, linha.getNome());
        stmt.setString(2, linha.getDescricao());
        stmt.setInt(3, linha.getNumero());

        stmt.executeUpdate();
        stmt.close();

        return "Linha de trem alterado com sucesso!";
    }

    public String excluir(int numero) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("DELETE FROM LINHA WHERE numero = ?");

        stmt.setInt(1, numero);

        stmt.execute();
        stmt.close();

        return "Linha deletada com sucesso!";
    }

    public List<Linha> selecionar() throws SQLException {
        List<Linha> listaLinha = new ArrayList<Linha>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select * from linha");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Linha linha = new Linha();
            linha.setNumero(rs.getInt(1));
            linha.setNome(rs.getString(2));
            linha.setDescricao(rs.getString(3));
            listaLinha.add(linha);
        }
        stmt.close();
        return listaLinha;
    }

    public Linha buscarLinhaPorNumero(int numero) throws SQLException {
        Linha linha = new Linha();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from linha where numero = ?");
        stmt.setInt(1, numero);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            linha.setNumero(rs.getInt(1));
            linha.setNome(rs.getString(2));
            linha.setDescricao(rs.getString(3));
        }
        stmt.close();
        return linha;
    }
}
