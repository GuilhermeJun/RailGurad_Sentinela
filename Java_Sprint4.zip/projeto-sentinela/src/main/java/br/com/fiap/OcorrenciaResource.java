package br.com.fiap;

import br.com.fiap.beans.Ocorrencia;
import br.com.fiap.bo.OcorrenciaBO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/ocorrencia")
public class OcorrenciaResource {
    private OcorrenciaBO ocorrenciaBO = new OcorrenciaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Ocorrencia> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<Ocorrencia>) ocorrenciaBO.selecionarBO();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response inserirRs(Ocorrencia ocorrencia, @Context UriInfo uriInfo) throws SQLException, ClassNotFoundException {
        ocorrenciaBO.inserirBO(ocorrencia);

        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(ocorrencia.getCodigo()));
        return Response.created(builder.build()).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizarRs(Ocorrencia ocorrencia, @PathParam("codigo") int codigo) throws SQLException, ClassNotFoundException {
        ocorrenciaBO.atualizarBO(ocorrencia);

        return Response.ok().build();
    }

    @DELETE
    @Path("/{codigo}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response excluirRs(@PathParam("codigo") int codigo) throws SQLException, ClassNotFoundException {
        ocorrenciaBO.excluirBO(codigo);

        return Response.ok().build();
    }
}
