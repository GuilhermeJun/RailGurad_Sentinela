package br.com.fiap.beans;

import java.util.Date;

public class Carro {
    private String codigo;
    private String descricao;
    private Date dataManutencao;
    private Trem trem;

    public Carro() {
        super();
    }

    public Carro(String codCarro, String descricao, Date dataManutencao) {
        super();
        this.codigo = codCarro;
        this.descricao = descricao;
        this.dataManutencao = dataManutencao;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public java.sql.Date getDataManutencao() {
        return (java.sql.Date) dataManutencao;
    }

    public void setDataManutencao(Date dataManutencao) {
        this.dataManutencao = dataManutencao;
    }

    public Trem getTrem() {
        return trem;
    }

    public void setTrem(Trem trem) {
        this.trem = trem;
    }

    @Override
    public String toString() {
        return "Carro{" +
                "\ncodCarro=" + codigo +
                "\ndescricao='" + descricao + '\'' +
                "\ndataManutencao=" + dataManutencao +
                "\ntrem=" + trem +
                '}';
    }
}
