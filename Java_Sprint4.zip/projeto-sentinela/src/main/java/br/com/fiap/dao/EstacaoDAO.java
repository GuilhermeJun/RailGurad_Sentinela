package br.com.fiap.dao;

import br.com.fiap.beans.Estacao;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstacaoDAO {

    public Connection minhaConexao;

    public EstacaoDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Estacao estacao) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO ESTACAO VALUES (?, ?, ?)");

        stmt.setString(1, estacao.getCodigo());
        stmt.setString(2, estacao.getNome());
        stmt.setString(3, estacao.getLocalizacao());

        stmt.execute();
        stmt.close();

        return "Estação cadastrado com sucesso!";
    }

    public String atualizar(Estacao estacao) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE ESTACAO SET NOME_ESTACAO = ?, LOCALIZACAO = ? WHERE COD_ESTACAO = ?");

        stmt.setString(1, estacao.getNome());
        stmt.setString(2, estacao.getLocalizacao());
        stmt.setString(3, estacao.getCodigo());

        stmt.executeUpdate();
        stmt.close();

        return "Estação alterado com sucesso!";
    }

    public String excluir(String codigo) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("DELETE FROM ESTACAO WHERE COD_ESTACAO = ?");

        stmt.setString(1, codigo);

        stmt.execute();
        stmt.close();

        return "Estacão deletada com sucesso!";
    }

    public List<Estacao> selecionar() throws SQLException {
        List<Estacao> listaEstacao = new ArrayList<Estacao>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select * from estacao");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Estacao estacao = new Estacao();
            estacao.setCodigo(rs.getString(1));
            estacao.setNome(rs.getString(2));
            estacao.setLocalizacao(rs.getString(3));
            listaEstacao.add(estacao);
        }
        return listaEstacao;
    }

    public Estacao buscarEstacaoPorCodigo(String codigo) throws SQLException {
        Estacao estacao = new Estacao();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from estacao where cod_estacao = ?");
        stmt.setString(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            estacao.setCodigo(rs.getString(1));
            estacao.setNome(rs.getString(2));
        }
        stmt.close();
        return estacao;
    }
}
