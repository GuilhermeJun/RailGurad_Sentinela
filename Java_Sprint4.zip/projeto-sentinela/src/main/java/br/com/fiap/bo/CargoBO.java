package br.com.fiap.bo;

import br.com.fiap.beans.Cargo;
import br.com.fiap.dao.CargoDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class CargoBO {
    CargoDAO cargoDAO;

    public ArrayList<Cargo> selecionarBO() throws SQLException, ClassNotFoundException {
        cargoDAO = new CargoDAO();

        return (ArrayList<Cargo>) cargoDAO.selecionar();
    }
}
