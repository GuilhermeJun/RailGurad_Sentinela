package br.com.fiap.dao;

import br.com.fiap.beans.Carro;
import br.com.fiap.beans.TipoOcorrencia;
import br.com.fiap.beans.Trem;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoOcorrenciaDAO {

    public Connection minhaConexao;

    public TipoOcorrenciaDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(TipoOcorrencia tipoOcorrencia) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO TIPO_OCORRENCIA VALUES (?, ?, ?)");

        stmt.setInt(1, tipoOcorrencia.getCodigo());
        stmt.setString(2, tipoOcorrencia.getNome());
        stmt.setString(3, tipoOcorrencia.getDescricao());

        stmt.execute();
        stmt.close();

        return "Tipo da ocorrência cadastrado com sucesso!";
    }

    public List<TipoOcorrencia> selecionar() throws SQLException {
        List<TipoOcorrencia> listaTipoOcorrencia = new ArrayList<TipoOcorrencia>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select * from tipo_ocorrencia");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            TipoOcorrencia tipoOcorrencia = new TipoOcorrencia();
            tipoOcorrencia.setCodigo(rs.getInt(1));
            tipoOcorrencia.setNome(rs.getString(2));
            tipoOcorrencia.setDescricao(rs.getString(3));

            listaTipoOcorrencia.add(tipoOcorrencia);
        }
        stmt.close();
        return listaTipoOcorrencia;
    }

    public TipoOcorrencia buscarTipoOcorrenciaPorCodigo(int codigo) throws SQLException {
        TipoOcorrencia tipoOcorrencia = new TipoOcorrencia();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from tipo_ocorrencia where cod_tipo_ocor = ?");
        stmt.setInt(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            tipoOcorrencia.setCodigo(rs.getInt(1));
            tipoOcorrencia.setNome(rs.getString(2));
            tipoOcorrencia.setDescricao(rs.getString(3));
        }
        stmt.close();
        return tipoOcorrencia;
    }
}
