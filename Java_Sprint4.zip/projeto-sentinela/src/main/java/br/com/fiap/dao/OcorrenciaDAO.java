package br.com.fiap.dao;

import br.com.fiap.beans.*;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OcorrenciaDAO {

    public Connection minhaConexao;

    public OcorrenciaDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Ocorrencia ocorrencia) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO OCORRENCIA VALUES (?, ?, ?, ?, ?, ?)");

        stmt.setInt(1, ocorrencia.getCodigo());
        stmt.setTimestamp(2, Timestamp.valueOf(ocorrencia.getData()));
        stmt.setInt(3, ocorrencia.getFuncionario().getCodigo());
        stmt.setInt(4, ocorrencia.getTipoOcorrencia().getCodigo());
        stmt.setString(5, ocorrencia.getCarro().getCodigo());
        stmt.setLong(6, ocorrencia.getCamera().getId());

        stmt.execute();
        stmt.close();

        return "Ocorrência gravada com sucesso!";
    }

    public String atualizar(Ocorrencia ocorrencia) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE OCORRENCIA SET data = ?, funcionario = ?, tipo_ocorrencia = ?, carro = ?, camera = ? WHERE codigo = ?");

        stmt.setTimestamp(1, Timestamp.valueOf(ocorrencia.getData()));
        stmt.setInt(2, ocorrencia.getFuncionario().getCodigo());
        stmt.setInt(3, ocorrencia.getTipoOcorrencia().getCodigo());
        stmt.setString(4, ocorrencia.getCarro().getCodigo());
        stmt.setLong(5, ocorrencia.getCamera().getId());
        stmt.setInt(6, ocorrencia.getCodigo());

        stmt.execute();
        stmt.close();

        return "Ocorrência atualizada com sucesso!";
    }

    public String excluir(int codigo) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("DELETE FROM OCORRENCIA WHERE codigo = ?");

        stmt.setInt(1, codigo);

        stmt.execute();
        stmt.close();

        return "Ocorrência excluída com sucesso!";
    }

    public List<Ocorrencia> selecionar() throws SQLException {
        List<Ocorrencia> listaOcorrencia = new ArrayList<Ocorrencia>();

        PreparedStatement stmt = minhaConexao.prepareStatement("SELECT \n" +
                "  o.cod_ocorrencia,\n" +
                "  o.data_ocorrencia,\n" +
                "\n" +
                "  f.cod_func,\n" +
                "  f.cpf,\n" +
                "  f.nome_func,\n" +
                "  f.data_nasc,\n" +
                "  f.salario,\n" +
                "  f.num_telefone,\n" +
                "  f.email,\n" +
                "\n" +
                "  cg.cod_cargo,\n" +
                "  cg.nome_cargo,\n" +
                "  cg.descricao_cargo,\n" +
                "\n" +
                "  e.cod_estacao,\n" +
                "  e.nome_estacao,\n" +
                "  e.localizacao,\n" +
                "\n" +
                "  t.cod_tipo_ocor,\n" +
                "  t.nome_tipo_ocor,\n" +
                "  t.descricao_ocor,\n" +
                "\n" +
                "  c.cod_carro,\n" +
                "  c.descricao_carro,\n" +
                "  c.data_manut_carro,\n" +
                "\n" +
                "  cam.id_camera,\n" +
                "  cam.nome_camera,\n" +
                "  cam.data_manut_camera,\n" +
                "  cam.modelo_camera\n" +
                "\n" +
                "FROM ocorrencia o\n" +
                "JOIN funcionario f ON o.fk_funcionario = f.cod_func\n" +
                "LEFT JOIN cargo cg ON f.fk_cargo = cg.cod_cargo\n" +
                "LEFT JOIN estacao e ON f.fk_estacao = e.cod_estacao\n" +
                "JOIN tipo_ocorrencia t ON o.fk_tipo_ocorrencia = t.cod_tipo_ocor\n" +
                "JOIN carro c ON o.fk_carro = c.cod_carro\n" +
                "JOIN camera cam ON o.fk_camera = cam.id_camera");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Ocorrencia ocorrencia = new Ocorrencia();
            ocorrencia.setCodigo(rs.getInt(1));
            ocorrencia.setData(rs.getTimestamp(2).toLocalDateTime());

            Funcionario funcionario = new Funcionario();
            funcionario.setCodigo(rs.getInt(3));
            funcionario.setCpf(rs.getString(4));
            funcionario.setNome(rs.getString(5));
            funcionario.setDataNasc(rs.getDate(6));
            funcionario.setSalario(rs.getDouble(7));
            funcionario.setTelefone(rs.getString(8));
            funcionario.setEmail(rs.getString(9));

            Cargo cargo = new Cargo();
            cargo.setCodigo(rs.getInt(10));
            cargo.setNome(rs.getString(11));
            cargo.setDescricao(rs.getString(12));

            Estacao estacao = new Estacao();
            estacao.setCodigo(rs.getString(13));
            estacao.setNome(rs.getString(14));
            estacao.setLocalizacao(rs.getString(15));

            TipoOcorrencia tipoOcorrencia = new TipoOcorrencia();
            tipoOcorrencia.setCodigo(rs.getInt(16));
            tipoOcorrencia.setNome(rs.getString(17));
            tipoOcorrencia.setDescricao(rs.getString(18));

            Carro carro = new Carro();
            carro.setCodigo(rs.getString(19));
            carro.setDescricao(rs.getString(20));
            carro.setDataManutencao(rs.getDate(21));

            Camera camera = new Camera();
            camera.setId(rs.getLong(22));
            camera.setNome(rs.getString(23));
            camera.setDataManutencao(rs.getDate(24));
            camera.setModelo(rs.getString(25));

            funcionario.setEstacao(estacao);
            funcionario.setCargo(cargo);
            ocorrencia.setFuncionario(funcionario);
            ocorrencia.setTipoOcorrencia(tipoOcorrencia);
            ocorrencia.setCarro(carro);
            ocorrencia.setCamera(camera);

            listaOcorrencia.add(ocorrencia);
        }
        stmt.close();
        return listaOcorrencia;
    }
}
