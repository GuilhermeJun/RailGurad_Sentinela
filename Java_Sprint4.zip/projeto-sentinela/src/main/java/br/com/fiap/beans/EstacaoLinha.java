package br.com.fiap.beans;

public class EstacaoLinha {
    private Estacao estacao;
    private Linha linha;
    private String baldeacao;

    public EstacaoLinha() {
        super();
    }

    public EstacaoLinha(Estacao estacao, Linha linha, String baldeacao) {
        this.estacao = estacao;
        this.linha = linha;
        this.baldeacao = baldeacao;
    }

    public Estacao getEstacao() {
        return estacao;
    }

    public void setEstacao(Estacao estacao) {
        this.estacao = estacao;
    }

    public Linha getLinha() {
        return linha;
    }

    public void setLinha(Linha linha) {
        this.linha = linha;
    }

    public String getBaldeacao() {
        return baldeacao;
    }

    public void setBaldeacao(String baldeacao) {
        this.baldeacao = baldeacao;
    }

    @Override
    public String toString() {
        return "EstacaoLinha{" +
                "estacao=" + estacao +
                ", linha=" + linha +
                ", baldeacao=" + baldeacao +
                '}';
    }
}
