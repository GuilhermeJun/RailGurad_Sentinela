package br.com.fiap.bo;

import br.com.fiap.beans.Linha;
import br.com.fiap.dao.LinhaDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class LinhaBO {
    LinhaDAO linhaDAO;

    public ArrayList<Linha> selecionarBO() throws SQLException, ClassNotFoundException {
        linhaDAO = new LinhaDAO();

        return (ArrayList<Linha>) linhaDAO.selecionar();
    }

    public void inserirBO(Linha linha) throws SQLException, ClassNotFoundException {
        LinhaDAO linhaDAO = new LinhaDAO();

        linhaDAO.inserir(linha);
    }

    public void atualizarBO(Linha linha) throws SQLException, ClassNotFoundException {
        LinhaDAO linhaDAO = new LinhaDAO();

        linhaDAO.atualizar(linha);
    }

    public void excluirBO(int numero) throws SQLException, ClassNotFoundException {
        linhaDAO = new LinhaDAO();

        linhaDAO.excluir(numero);
    }
}
