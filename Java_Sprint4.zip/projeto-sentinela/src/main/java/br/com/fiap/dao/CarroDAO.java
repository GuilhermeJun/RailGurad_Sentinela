package br.com.fiap.dao;

import br.com.fiap.beans.Carro;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarroDAO {

    public Connection minhaConexao;

    public CarroDAO() throws SQLException, ClassNotFoundException {
        super();
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Carro carro) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO CARRO VALUES (?, ?, ?, ?)");

        stmt.setString(1, carro.getCodigo());
        stmt.setString(2, carro.getDescricao());
        stmt.setDate(3, carro.getDataManutencao());
        stmt.setString(4, carro.getTrem().getCodigo());

        stmt.execute();
        stmt.close();

        return "Carro cadastrado com sucesso!";
    }

    public List<Carro> selecionar() throws SQLException {
        List<Carro> listaCarro = new ArrayList<Carro>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select c.cod_carro, c.descricao_carro, c.data_manut_carro, t.cod_trem, t.numero_serie, t.fabricante, s.cod_status, s.tipo_status, s.descricao_status from carro c join trem t on c.fk_trem = t.cod_trem join status_trem s on t.fk_status_trem = s.cod_status");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Carro carro = new Carro();
            carro.setCodigo(rs.getString(1));
            carro.setDescricao(rs.getString(2));
            carro.setDataManutencao(rs.getDate(3));

            Trem trem = new Trem();
            trem.setCodigo(rs.getString(4));
            trem.setNumeroSerie(rs.getInt(5));
            trem.setFabricante(rs.getString(6));

            StatusTrem statusTrem = new StatusTrem();
            statusTrem.setCodigo(rs.getString(7));
            statusTrem.setTipoStatus(rs.getString(8));
            statusTrem.setDescricao(rs.getString(9));

            trem.setStatusTrem(statusTrem);
            carro.setTrem(trem);
            listaCarro.add(carro);
        }
        stmt.close();
        return listaCarro;
    }

    public Carro buscarPorCodigo(String codigo) throws SQLException {
        Carro carro = new Carro();
        Trem trem = new Trem();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from carro where cod_carro = ?");
        stmt.setString(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            carro.setCodigo(rs.getString(1));
            carro.setDescricao(rs.getString(2));
            carro.setDataManutencao(rs.getDate(3));
            carro.setTrem(trem);
        }
        stmt.close();
        return carro;
    }
}
