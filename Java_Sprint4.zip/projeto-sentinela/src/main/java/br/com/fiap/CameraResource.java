package br.com.fiap;

import br.com.fiap.beans.Camera;
import br.com.fiap.bo.CameraBO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/camera")
public class CameraResource {

    private CameraBO cameraBO = new CameraBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Camera> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<Camera>) cameraBO.selecionarBO();
    }
}
