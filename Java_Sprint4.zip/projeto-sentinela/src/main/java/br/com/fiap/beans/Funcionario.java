package br.com.fiap.beans;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Funcionario {
    private int codigo;
    private String cpf;
    private String nome;
    private Date dataNasc;
    private double salario;
    private String telefone;
    private String email;
    private String senha;
    private Cargo cargo;
    private Estacao estacao;

    public Funcionario() {
        super();
    }

    public Funcionario(int codigo, String cpf, String nome, Date dataNasc, double salario, String telefone, String email, String senha) {
        super();
        this.codigo = codigo;
        this.cpf = cpf;
        this.nome = nome;
        this.dataNasc = dataNasc;
        this.salario = salario;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public java.sql.Date getDataNasc() {
        return (java.sql.Date) dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Estacao getEstacao() {
        return estacao;
    }

    public void setEstacao(Estacao estacao) {
        this.estacao = estacao;
    }

    @Override
    public String toString() {
        return "Funcionario{" +
                "codigo=" + codigo +
                ", cpf='" + cpf + '\'' +
                ", nome='" + nome + '\'' +
                ", dataNasc=" + dataNasc +
                ", salario=" + salario +
                ", telefone='" + telefone + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                ", cargo=" + cargo +
                ", estacao=" + estacao +
                '}';
    }
}
