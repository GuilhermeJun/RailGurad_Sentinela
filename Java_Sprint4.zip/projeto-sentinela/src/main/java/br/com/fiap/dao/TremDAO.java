package br.com.fiap.dao;

import br.com.fiap.beans.Carro;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TremDAO {

    public Connection minhaConexao;

    public TremDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Trem trem) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO TREM VALUES (?, ?, ?, ?)");

        stmt.setString(1, trem.getCodigo());
        stmt.setInt(2, trem.getNumeroSerie());
        stmt.setString(3, trem.getFabricante());
        stmt.setString(4, trem.getStatusTrem().getCodigo());

        stmt.execute();
        stmt.close();

        return "Trem cadastrado com sucesso!";
    }

    public List<Trem> selecionar() throws SQLException, ClassNotFoundException {
        List<Trem> listaTrem = new ArrayList<Trem>();

        PreparedStatement stmt = minhaConexao.prepareStatement("SELECT t.cod_trem, t.numero_serie, t.fabricante, s.cod_status, s.tipo_status, s.descricao_status FROM trem t JOIN status_trem s ON t.fk_status_trem = s.cod_status");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Trem trem = new Trem();

            trem.setCodigo(rs.getString(1));
            trem.setNumeroSerie(rs.getInt(2));
            trem.setFabricante(rs.getString(3));

            StatusTrem statusTrem = new StatusTrem();
            statusTrem.setCodigo(rs.getString(4));
            statusTrem.setTipoStatus(rs.getString(5));
            statusTrem.setDescricao(rs.getString(6));
            trem.setStatusTrem(statusTrem);

            listaTrem.add(trem);
        }
        stmt.close();
        return listaTrem;
    }

    public Trem buscarPorCodigo(String codigo) throws SQLException {
        Trem trem = new Trem();
        StatusTrem statusTrem = new StatusTrem();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from trem where cod_trem = ?");
        stmt.setString(1, codigo);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            trem.setCodigo(rs.getString(1));
            trem.setNumeroSerie(rs.getInt(2));
            trem.setFabricante(rs.getString(3));
        }
        stmt.close();
        return trem;
    }
}
