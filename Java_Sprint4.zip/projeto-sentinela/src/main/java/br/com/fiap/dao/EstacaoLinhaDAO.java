package br.com.fiap.dao;

import br.com.fiap.beans.Estacao;
import br.com.fiap.beans.EstacaoLinha;
import br.com.fiap.beans.Linha;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstacaoLinhaDAO {

    public Connection minhaConexao;

    public EstacaoLinhaDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(EstacaoLinha estacaoLinha) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO ESTACAOLINHA VALUES (?, ?, ?)");

        stmt.setString(1, estacaoLinha.getEstacao().getCodigo());
        stmt.setInt(2, estacaoLinha.getLinha().getNumero());
        stmt.setString(3, estacaoLinha.getBaldeacao());

        stmt.execute();
        stmt.close();

        return "Estação_Linha inserido com sucesso!";
    }

    public List<EstacaoLinha> selecionar() throws SQLException {
        List<EstacaoLinha> listaEstacaoLinha = new ArrayList<EstacaoLinha>();

        PreparedStatement stmt = minhaConexao.prepareStatement("select e.cod_estacao, e.nome_estacao, e.localizacao, l.numero, l.nome_linha, l.descr_linha, b.baldeacao from estacao_linha b join estacao e on b.fk_estacao = e.cod_estacao join linha l on b.fk_linha = l.numero");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Estacao estacao = new Estacao();
            estacao.setCodigo(rs.getString(1));
            estacao.setNome(rs.getString(2));
            estacao.setLocalizacao(rs.getString(3));

            Linha linha = new Linha();
            linha.setNumero(rs.getInt(4));
            linha.setNome(rs.getString(5));
            linha.setDescricao(rs.getString(6));

            EstacaoLinha estacaoLinha = new EstacaoLinha();
            estacaoLinha.setBaldeacao(rs.getString(7));
            estacaoLinha.setEstacao(estacao);
            estacaoLinha.setLinha(linha);

            listaEstacaoLinha.add(estacaoLinha);
        }
        stmt.close();
        return listaEstacaoLinha;
    }
}
