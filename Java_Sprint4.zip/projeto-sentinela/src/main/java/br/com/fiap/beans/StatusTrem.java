package br.com.fiap.beans;

public class StatusTrem {
    private String codigo;
    private String tipoStatus;
    private String descricao;

    public StatusTrem() {
        super();
    }

    public StatusTrem(String codStatusTrem, String tipoStatus, String descricaoStatusTrem) {
        super();
        this.codigo = codStatusTrem;
        this.tipoStatus = tipoStatus;
        this.descricao = descricaoStatusTrem;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipoStatus() {
        return tipoStatus;
    }

    public void setTipoStatus(String tipoStatus) {
        this.tipoStatus = tipoStatus;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "StatusTrem{" +
                "\ncodStatusTrem=" + codigo +
                "\ntipoStatus='" + tipoStatus + '\'' +
                "\ndescricaoStatusTrem='" + descricao + '\'' +
                '}';
    }
}
