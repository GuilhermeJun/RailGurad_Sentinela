package br.com.fiap;

import br.com.fiap.beans.Linha;
import br.com.fiap.bo.LinhaBO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/linha")
public class LinhaResource {

    private LinhaBO linhaBO = new LinhaBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Linha> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<Linha>) linhaBO.selecionarBO();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response inserirRs(Linha linha, @Context UriInfo uriInfo) throws SQLException, ClassNotFoundException {
        linhaBO.inserirBO(linha);

        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(linha.getNumero()));
        return Response.created(builder.build()).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizarRs(Linha linha, @PathParam("numero") int numero) throws SQLException, ClassNotFoundException {
        linhaBO.atualizarBO(linha);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{numero}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response excluirRs(@PathParam("numero") int numero) throws SQLException, ClassNotFoundException {
        linhaBO.excluirBO(numero);
        return Response.ok().build();
    }
}
