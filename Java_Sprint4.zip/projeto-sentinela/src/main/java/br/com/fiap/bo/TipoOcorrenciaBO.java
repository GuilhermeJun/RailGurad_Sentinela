package br.com.fiap.bo;

import br.com.fiap.beans.TipoOcorrencia;
import br.com.fiap.dao.TipoOcorrenciaDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class TipoOcorrenciaBO {
    TipoOcorrenciaDAO tipoOcorrenciaDAO;

    public ArrayList<TipoOcorrencia> selecionarBO() throws SQLException, ClassNotFoundException {
        tipoOcorrenciaDAO = new TipoOcorrenciaDAO();

        return (ArrayList<TipoOcorrencia>) tipoOcorrenciaDAO.selecionar();
    }
}
