package br.com.fiap.dao;

import br.com.fiap.beans.Camera;
import br.com.fiap.beans.Carro;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.connections.ConnectionFactory;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class CameraDAO {

    public Connection minhaConexao;

    public CameraDAO() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConnectionFactory().conexao();
    }

    public String inserir(Camera camera) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("INSERT INTO CAMERA VALUES (?, ?, ?, ?, ?)");

        stmt.setLong(1, camera.getId());
        stmt.setString(2, camera.getNome());
        stmt.setDate(3, camera.getDataManutencao());
        stmt.setString(4, camera.getModelo());
        stmt.setString(5, camera.getCarro().getCodigo());

        stmt.execute();
        stmt.close();

        return "Camera cadastrado com sucesso!";
    }

    public String alterar(Camera camera) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE CAMERA SET nome_camera = ?, data_manut_camera = ?, modelo_camera = ? WHERE id_camera = ?");
        stmt.setString(1, camera.getNome());
        stmt.setDate(2, camera.getDataManutencao());
        stmt.setString(3, camera.getModelo());
        stmt.setLong(4, camera.getId());
        stmt.executeUpdate();
        stmt.close();
        return "Camera alterado com sucesso!";
    }

    public String excluir(long id) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement("DELETE FROM CAMERA WHERE id_camera = ?");

        stmt.setLong(1, id);
        stmt.execute();
        stmt.close();
        return "Câmera excluida com sucesso!";
    }

    public List<Camera> selecionar() throws SQLException {
        List<Camera> listaCamera = new ArrayList<Camera>();

        PreparedStatement stmt = minhaConexao.prepareStatement("\n" +
                "SELECT \n" +
                "    cam.id_camera,\n" +
                "    cam.nome_camera,\n" +
                "    cam.data_manut_camera,\n" +
                "    cam.modelo_camera,\n" +
                "\n" +
                "    c.cod_carro,\n" +
                "    c.descricao_carro,\n" +
                "    c.data_manut_carro,\n" +
                "\n" +
                "    t.cod_trem,\n" +
                "    t.numero_serie,\n" +
                "    t.fabricante,\n" +
                "\n" +
                "    s.cod_status,\n" +
                "    s.tipo_status,\n" +
                "    s.descricao_status\n" +
                "FROM \n" +
                "    camera cam\n" +
                "JOIN \n" +
                "    carro c ON cam.fk_carro = c.cod_carro\n" +
                "JOIN \n" +
                "    trem t ON c.fk_trem = t.cod_trem\n" +
                "JOIN \n" +
                "    status_trem s ON t.fk_status_trem = s.cod_status");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Camera camera = new Camera();
            camera.setId(rs.getLong(1));
            camera.setNome(rs.getString(2));
            camera.setDataManutencao(rs.getDate(3));
            camera.setModelo(rs.getString(4));

            Carro carro = new Carro();
            carro.setCodigo(rs.getString(5));
            carro.setDescricao(rs.getString(6));
            carro.setDataManutencao(rs.getDate(7));

            Trem trem = new Trem();
            trem.setCodigo(rs.getString(8));
            trem.setNumeroSerie(rs.getInt(9));
            trem.setFabricante(rs.getString(10));

            StatusTrem statusTrem = new StatusTrem();
            statusTrem.setCodigo(rs.getString(11));
            statusTrem.setTipoStatus(rs.getString(12));
            statusTrem.setDescricao(rs.getString(13));

            trem.setStatusTrem(statusTrem);
            carro.setTrem(trem);
            camera.setCarro(carro);

            listaCamera.add(camera);
        }
        stmt.close();
        return listaCamera;
    }

    public Camera buscarPorId(long id) throws SQLException {
        Camera camera = new Camera();
        PreparedStatement stmt = minhaConexao.prepareStatement("select * from camera where id_camera = ?");
        stmt.setLong(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            camera.setId(rs.getLong(1));
            camera.setNome(rs.getString(2));
            camera.setDataManutencao(rs.getDate(3));
            camera.setModelo(rs.getString(4));
        }
        stmt.close();
        return camera;
    }
}
