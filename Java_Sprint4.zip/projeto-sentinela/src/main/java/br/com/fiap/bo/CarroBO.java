package br.com.fiap.bo;

import br.com.fiap.beans.Carro;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.dao.CarroDAO;
import br.com.fiap.dao.StatusTremDAO;
import br.com.fiap.dao.TremDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarroBO {
    CarroDAO carroDAO;
    TremDAO tremDAO;
    StatusTremDAO statusTremDAO;

    public ArrayList<Carro> selecionarBO() throws SQLException, ClassNotFoundException {
        carroDAO = new CarroDAO();
        tremDAO = new TremDAO();
        statusTremDAO = new StatusTremDAO();

        List<Carro> listaCarro = carroDAO.selecionar();

        for (Carro carro : listaCarro) {
            Trem trem = carro.getTrem();
            if (trem != null && trem.getCodigo() != null && trem.getStatusTrem() != null) {
                StatusTrem statusTrem = statusTremDAO.buscarStatusTremPorCodigo(trem.getStatusTrem().getCodigo());
                trem.setStatusTrem(statusTrem);
                carro.setTrem(trem);
            }
        }
        return (ArrayList<Carro>) carroDAO.selecionar();
    }
}
