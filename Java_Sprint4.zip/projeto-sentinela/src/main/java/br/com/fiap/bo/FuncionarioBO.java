package br.com.fiap.bo;

import br.com.fiap.beans.Funcionario;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.dao.CargoDAO;
import br.com.fiap.dao.FuncionarioDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioBO {
    FuncionarioDAO funcionarioDAO;
    CargoDAO cargoDAO;
    EstacaoBO estacaoBO;

    public ArrayList<Funcionario> selecionarBO() throws SQLException, ClassNotFoundException {
        funcionarioDAO = new FuncionarioDAO();

        List<Funcionario> listaFuncionario = funcionarioDAO.selecionar();

        return (ArrayList<Funcionario>) funcionarioDAO.selecionar();
    }
}
