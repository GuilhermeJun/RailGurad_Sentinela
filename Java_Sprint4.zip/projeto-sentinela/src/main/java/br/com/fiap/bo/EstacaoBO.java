package br.com.fiap.bo;

import br.com.fiap.beans.Estacao;
import br.com.fiap.dao.EstacaoDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class EstacaoBO {
    EstacaoDAO estacaoDAO;

    public ArrayList<Estacao> selecionarBO() throws SQLException, ClassNotFoundException {
        estacaoDAO = new EstacaoDAO();

        return (ArrayList<Estacao>) estacaoDAO.selecionar();
    }

    public void inserirBO(Estacao estacao) throws SQLException, ClassNotFoundException {
        EstacaoDAO estacaoDAO = new EstacaoDAO();

        estacaoDAO.inserir(estacao);
    }

    public void atualizarBO(Estacao estacao) throws SQLException, ClassNotFoundException {
        EstacaoDAO estacaoDAO = new EstacaoDAO();

        estacaoDAO.atualizar(estacao);
    }

    public void excluirBO(String codigo) throws SQLException, ClassNotFoundException {
        EstacaoDAO estacaoDAO = new EstacaoDAO();

        estacaoDAO.excluir(codigo);
    }
}
