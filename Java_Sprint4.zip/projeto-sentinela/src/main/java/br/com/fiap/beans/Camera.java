package br.com.fiap.beans;

import java.sql.Date;

public class Camera {
    private Long id;
    private String nome;
    private String modelo;
    private Date dataManutencao;
    private Carro carro;

    public Camera() {
        super();
    }

    public Camera(Long id, String nomeCamera, String modelo, Date dataManutencao) {
        super();
        this.id = id;
        this.nome = nomeCamera;
        this.modelo = modelo;
        this.dataManutencao = dataManutencao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Date getDataManutencao() {
        return dataManutencao;
    }

    public void setDataManutencao(Date dataManutencao) {
        this.dataManutencao = dataManutencao;
    }

    public Carro getCarro() {
        return carro;
    }

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    @Override
    public String toString() {
        return "Camera{" +
                "\nid=" + id +
                "\nnomeCamera='" + nome + '\'' +
                "\nmodelo='" + modelo + '\'' +
                "\ndataManutencao=" + dataManutencao +
                "\ncarro=" + carro +
                '}';
    }
}
