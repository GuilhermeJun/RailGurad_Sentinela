package br.com.fiap.bo;

import br.com.fiap.beans.Camera;
import br.com.fiap.beans.Carro;
import br.com.fiap.beans.StatusTrem;
import br.com.fiap.beans.Trem;
import br.com.fiap.dao.CameraDAO;
import br.com.fiap.dao.CarroDAO;
import br.com.fiap.dao.StatusTremDAO;
import br.com.fiap.dao.TremDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CameraBO {
    CameraDAO cameraDAO;
    CarroDAO carroDAO;
    TremDAO tremDAO;
    StatusTremDAO statusTremDAO;

    public ArrayList<Camera> selecionarBO() throws SQLException, ClassNotFoundException {
        cameraDAO = new CameraDAO();
        carroDAO = new CarroDAO();
        tremDAO = new TremDAO();
        statusTremDAO = new StatusTremDAO();

        List<Camera> listaCamera = cameraDAO.selecionar();

        for (Camera camera : listaCamera) {
            Carro carro = carroDAO.buscarPorCodigo(camera.getCarro().getCodigo());
            camera.setCarro(carro);
            if ( carro != null && carro.getCodigo() != null) {
                Trem trem = tremDAO.buscarPorCodigo(carro.getTrem().getCodigo());
                carro.setTrem(trem);
                if (trem != null && trem.getCodigo() != null) {
                    StatusTrem statusTrem = statusTremDAO.buscarStatusTremPorCodigo(trem.getStatusTrem().getCodigo());
                    trem.setStatusTrem(statusTrem);
                    carro.getTrem().setStatusTrem(statusTrem);
                }
            }
        }
        return (ArrayList<Camera>) cameraDAO.selecionar();
    }
}
