package br.com.fiap.beans;

import java.time.LocalDateTime;

public class Ocorrencia {
    private int codigo;
    private LocalDateTime data;
    private Funcionario funcionario;
    private TipoOcorrencia tipoOcorrencia;
    private Carro carro;
    private Camera camera;

    public Ocorrencia() {
        super();
    }

    public Ocorrencia(int codigo, LocalDateTime dataOcorrencia) {
        super();
        this.codigo = codigo;
        this.data = dataOcorrencia;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public TipoOcorrencia getTipoOcorrencia() {
        return tipoOcorrencia;
    }

    public void setTipoOcorrencia(TipoOcorrencia tipoOcorrencia) {
        this.tipoOcorrencia = tipoOcorrencia;
    }

    public Carro getCarro() {
        return carro;
    }

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    public Camera getCamera() {
        return camera;
    }

    public void setCamera(Camera camera) {
        this.camera = camera;
    }

    @Override
    public String toString() {
        return "Ocorrencia{" +
                "\ncodOcorrencia=" + codigo +
                "\ndataOcorrencia=" + data +
                "\nfuncionario=" + funcionario +
                "\ntipoOcorrencia=" + tipoOcorrencia +
                "\ncarro=" + carro +
                "\ncamera=" + camera +
                '}';
    }

    public String exibirOcorrenciaPorTipo() {
        return "OCORRÊNCIA POR TIPO\n\nTipo de ocorrência: " + getTipoOcorrencia().getNome() +
                "\nData da ocorrência: " + getData();
    }

    public String exibirOcorrenciaPorTrem() {
        return "OCORRÊNCIA POR TREM\n" +
                "\nTrem: " + getCarro().getTrem().getNumeroSerie() +
                "\nCarro: " + getCarro().getCodigo() +
                "\nData da ocorrência: " + getData();
    }
}
