package br.com.fiap;

import br.com.fiap.beans.Cargo;
import br.com.fiap.bo.CargoBO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;

import java.sql.SQLException;
import java.util.ArrayList;

@Provider
@Path("/cargo")
public class CargoResource {
    private CargoBO cargoBO = new CargoBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Cargo> selecionarBO() throws SQLException, ClassNotFoundException {
        return (ArrayList<Cargo>) cargoBO.selecionarBO();
    }
}
