package br.com.fiap.main;

import br.com.fiap.beans.*;
import br.com.fiap.dao.EstacaoDAO;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

    static String texto(String j) {
        return JOptionPane.showInputDialog(j);
    }

    static int inteiro(String j) {
        return Integer.parseInt(texto(j));
    }

    static Date data(String j) throws ParseException {
        return new SimpleDateFormat("dd/MM/yyyy").parse(texto(j));
    }

    static Date hora(String j) throws ParseException {
        return new SimpleDateFormat("HH:mm:ss").parse(texto(j));
    }

    public static void main(String[] args) throws ParseException, SQLException, ClassNotFoundException {
        Estacao objEstacao = new Estacao();
        EstacaoDAO estacaoDAO = new EstacaoDAO();

        /*
        objEstacao.setCodEstacao(texto("Código da estação: ")); //Ex: OSA (Osasco)
        objEstacao.setNome(texto("Nome da estação: "));
        objEstacao.setLinha(texto("Linha: ")); //Ex: L8 e L9
        objEstacao.setPlataforma(texto("Plataforma: "));

        System.out.println(estacaoDAO.inserir(objEstacao));

        Ocorrencia objOcorrencia = new Ocorrencia(
                inteiro("Código da ocorrência:"), data("Data:"), hora("Hora:")
        );

        TipoOcorrencia objTipoOcorrencia = new TipoOcorrencia(
                inteiro("Código do tipo da ocorrência:"), texto("Nome da ocorrência:"), texto("Descrição do tipo da ocorrência:")
        );

        objOcorrencia.setTipoOcorrencia(objTipoOcorrencia);

        Camera objCamera = new Camera(
                inteiro("ID da câmera:"), texto("Nome da câmera:"), texto("Modelo da câmera:"), data("Data de manutenção:")
        );

        objOcorrencia.setCamera(objCamera);

        Carro objCarro = new Carro(
                texto("Código do carro:"), texto("Descrição do carro:"), data("Data de manutenção:")
        );

        objCamera.setCarro(objCarro);

        Trem objTrem = new Trem(
                texto("Código do trem:"), inteiro("Número de série do trem:"), texto("Fabricante:")
        );

        objCarro.setTrem(objTrem);

        System.out.println("OCORRÊNCIA\n\n" + objOcorrencia + "\n" + objTipoOcorrencia);
        System.out.println("\nOCORRÊNCIA POR TIPO\n" + objOcorrencia.exibirOcorrenciaPorTipo());
        System.out.println("\nOCORRÊNCIA POR TREM\n" + objOcorrencia.exibirOcorrenciaPorTrem());
        */

    }
}